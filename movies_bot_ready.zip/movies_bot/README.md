# Movies Bot (только фильмы)

API: `GET /api/movies/` + `POST /api/movies/generate`

## Запуск

```bash
cd movies_bot
pip install -r requirements.txt
cp .env.example .env
# BOT_TOKEN, GRTKNIV_API_KEY, WEBHOOK_BASE_URL
python main.py
```

Webhook слушает порт **8081** (чтобы не конфликтовать с poses-ботом на 8080).

## Пользователь

- 🎬 Фильм → фото → выбор шаблона → Запустить
- Профиль, Stars, промокод

## Админ `/admin`

Статистика, юзер/баланс, рассылка, промо, цена фильма, канал, курс Stars, API баланс
