from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator
from typing import List


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    BOT_TOKEN: str
    ADMIN_IDS: List[int] = [520446047]

    GRTKNIV_API_KEY: str = ""
    GRTKNIV_BASE_URL: str = "https://api.grtkniv.net"

    WEBHOOK_BASE_URL: str = "https://your-domain.com"

    DATABASE_URL: str = "sqlite+aiosqlite:///./data/movies_bot.db"

    DEFAULT_PRICE_MOVIE: int = 150
    STARS_TO_COINS: int = 10

    @field_validator("ADMIN_IDS", mode="before")
    @classmethod
    def parse_admin_ids(cls, v):
        if isinstance(v, str):
            return [int(x.strip()) for x in v.split(",") if x.strip()]
        if isinstance(v, int):
            return [v]
        return v


settings = Settings()
