"""Клиент API — только Movies."""
from __future__ import annotations

import uuid
from typing import Any, Optional

import aiohttp
from loguru import logger

from bot.config import settings


class GrtknivAPI:
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or settings.GRTKNIV_API_KEY
        self.base_url = (base_url or settings.GRTKNIV_BASE_URL).rstrip("/")
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"Authorization": self.api_key},
                timeout=aiohttp.ClientTimeout(total=90, connect=20),
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    def _new_id_gen(self) -> str:
        return f"movie_{uuid.uuid4().hex[:16]}"

    async def get_movies(self) -> list[dict]:
        """GET /api/movies/ — список шаблонов (id, name, image, video, duration)."""
        session = await self._get_session()
        async with session.get(f"{self.base_url}/api/movies/") as resp:
            if resp.status != 200:
                text = await resp.text()
                logger.error(f"get_movies {resp.status}: {text}")
                return []
            data = await resp.json()
            return data if isinstance(data, list) else []

    async def generate_movie(
        self,
        image_bytes: bytes,
        movie_id: str,
        filename: str = "photo.jpg",
        webhook: str | None = None,
        id_gen: str | None = None,
    ) -> dict[str, Any]:
        """POST /api/movies/generate — id_gen, movieId, file, webhook."""
        id_gen = id_gen or self._new_id_gen()
        data = aiohttp.FormData()
        data.add_field("id_gen", id_gen)
        data.add_field("movieId", movie_id)
        data.add_field("file", image_bytes, filename=filename, content_type="image/jpeg")
        if webhook:
            data.add_field("webhook", webhook)

        session = await self._get_session()
        async with session.post(f"{self.base_url}/api/movies/generate", data=data) as resp:
            try:
                result = await resp.json(content_type=None)
            except Exception:
                result = {"error": await resp.text()}

            if resp.status == 200:
                result["id_gen"] = result.get("id_gen") or id_gen
                return result
            logger.error(f"generate_movie {resp.status}: {result}")
            return {
                "error": result.get("error") or result.get("message") or str(result),
                "status": resp.status,
            }

    async def get_balance(self) -> dict:
        session = await self._get_session()
        async with session.get(f"{self.base_url}/api/profile/balance") as resp:
            if resp.status != 200:
                return {"error": await resp.text()}
            return await resp.json()


api_client = GrtknivAPI()
