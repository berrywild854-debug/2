from __future__ import annotations

from typing import Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from bot.database import User, Transaction, Generation, PromoCode, PromoUsage


async def get_or_create_user(
    session: AsyncSession,
    telegram_id: int,
    username: str | None = None,
    full_name: str | None = None,
) -> User:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    user = result.scalar_one_or_none()
    if user:
        if username is not None:
            user.username = username
        if full_name is not None:
            user.full_name = full_name
        await session.commit()
        return user

    user = User(telegram_id=telegram_id, username=username, full_name=full_name, balance=0.0)
    session.add(user)
    try:
        await session.commit()
        await session.refresh(user)
        return user
    except Exception:
        await session.rollback()
        result = await session.execute(select(User).where(User.telegram_id == telegram_id))
        user = result.scalar_one()
        if username is not None:
            user.username = username
        if full_name is not None:
            user.full_name = full_name
        await session.commit()
        return user


async def change_balance(
    session: AsyncSession,
    user: User,
    amount: float,
    tx_type: str,
    description: str = "",
    payment_id: str | None = None,
) -> User:
    user.balance = round(user.balance + amount, 2)
    session.add(
        Transaction(
            user_id=user.id,
            amount=amount,
            tx_type=tx_type,
            description=description,
            payment_id=payment_id,
        )
    )
    await session.commit()
    await session.refresh(user)
    return user


async def get_user_by_tg(session: AsyncSession, telegram_id: int) -> Optional[User]:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    return result.scalar_one_or_none()


async def get_stats(session: AsyncSession) -> dict:
    users_count = await session.scalar(select(func.count(User.id))) or 0
    gens_count = await session.scalar(select(func.count(Generation.id))) or 0
    gens_done = await session.scalar(
        select(func.count(Generation.id)).where(Generation.status == "done")
    ) or 0
    return {"users": users_count, "generations": gens_count, "generations_done": gens_done}


async def apply_promo(session: AsyncSession, user: User, code: str) -> tuple[bool, str]:
    result = await session.execute(select(PromoCode).where(PromoCode.code == code.upper()))
    promo = result.scalar_one_or_none()
    if not promo or not promo.is_active:
        return False, "Промокод не найден или неактивен."
    if promo.max_uses > 0 and promo.used_count >= promo.max_uses:
        return False, "Промокод уже исчерпан."
    used = await session.execute(
        select(PromoUsage).where(PromoUsage.promo_id == promo.id, PromoUsage.user_id == user.id)
    )
    if used.scalar_one_or_none():
        return False, "Вы уже использовали этот промокод."
    promo.used_count += 1
    session.add(PromoUsage(promo_id=promo.id, user_id=user.id))
    await change_balance(session, user, promo.amount, "promo", f"Промокод {promo.code}")
    return True, f"✅ Начислено {promo.amount:.0f} монет!"
