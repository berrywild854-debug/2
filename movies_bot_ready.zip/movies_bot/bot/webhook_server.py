from __future__ import annotations

from datetime import datetime

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from loguru import logger
from sqlalchemy import select

from bot.database import Generation, User, async_session

bot = None
app = FastAPI(title="Movies Webhook")


def set_bot(bot_instance):
    global bot
    bot = bot_instance


@app.post("/webhook/generation")
async def generation_webhook(request: Request):
    try:
        content_type = request.headers.get("content-type", "")
        data = {}
        if "multipart" in content_type:
            form = await request.form()
            for k, v in form.items():
                if hasattr(v, "read"):
                    continue
                data[k] = str(v)
        else:
            try:
                data = await request.json()
            except Exception:
                return JSONResponse({"ok": False}, status_code=400)

        logger.info(f"Webhook: {data}")
        id_gen = data.get("id_gen")
        if not id_gen:
            return JSONResponse({"ok": False, "error": "no id_gen"}, status_code=400)

        error = data.get("error")
        result_url = (
            data.get("video_url")
            or data.get("result_pv_url")
            or data.get("image_url")
        )

        async with async_session() as session:
            result = await session.execute(select(Generation).where(Generation.id_gen == id_gen))
            gen = result.scalar_one_or_none()
            if not gen:
                return JSONResponse({"ok": True, "msg": "unknown"})

            user = (
                await session.execute(select(User).where(User.id == gen.user_id))
            ).scalar_one_or_none()
            if not user:
                return JSONResponse({"ok": True})

            if error:
                gen.status = "error"
                gen.error_message = error
                gen.finished_at = datetime.utcnow()
                await session.commit()
                if bot:
                    try:
                        await bot.send_message(user.telegram_id, f"❌ Фильм {id_gen}: {error}")
                    except Exception:
                        pass
            else:
                gen.status = "done"
                gen.result_url = result_url
                gen.finished_at = datetime.utcnow()
                await session.commit()
                if bot and result_url:
                    try:
                        await bot.send_video(
                            user.telegram_id, result_url, caption=f"✅ Фильм готов!\nID: {id_gen}"
                        )
                    except Exception:
                        try:
                            await bot.send_message(
                                user.telegram_id, f"✅ Готово!\n{result_url}"
                            )
                        except Exception:
                            pass

        return JSONResponse({"ok": True})
    except Exception as e:
        logger.exception("webhook")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)


@app.get("/health")
async def health():
    return {"status": "ok"}
