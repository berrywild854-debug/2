from __future__ import annotations

import asyncio

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from bot.config import settings
from bot.database import Generation, PromoCode, User, get_setting, set_setting
from bot.keyboards.admin_kb import (
    admin_menu_kb,
    channel_kb,
    confirm_broadcast_kb,
    promo_menu_kb,
    user_actions_kb,
)
from bot.services.grtkniv_api import api_client
from bot.services.user_service import change_balance, get_stats, get_user_by_tg
from bot.states.user_states import AdminStates

router = Router(name="admin")


def is_admin(uid: int) -> bool:
    return uid in settings.ADMIN_IDS


@router.message(Command("admin"))
async def admin_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    await message.answer("🔧 Админ (Movies)", reply_markup=admin_menu_kb())


@router.callback_query(F.data == "adm:menu")
async def adm_menu(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.clear()
    await callback.message.answer("🔧 Админ (Movies)", reply_markup=admin_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "adm:stats")
async def adm_stats(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    s = await get_stats(session)
    await callback.message.answer(
        f"📊 Юзеров: {s['users']}\nФильмов: {s['generations']}\nУспешных: {s['generations_done']}",
        reply_markup=admin_menu_kb(),
    )
    await callback.answer()


@router.callback_query(F.data == "adm:price")
async def adm_price(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    p = await get_setting(session, "price_movie")
    await state.set_state(AdminStates.waiting_price)
    await callback.message.answer(f"Текущая цена фильма: {p}\nВведи новую:")
    await callback.answer()


@router.message(AdminStates.waiting_price)
async def save_price(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    try:
        val = int(float(message.text.strip()))
        await set_setting(session, "price_movie", str(val))
        await message.answer(f"✅ Цена фильма: {val}", reply_markup=admin_menu_kb())
    except ValueError:
        await message.answer("Нужно число")
    await state.clear()


@router.callback_query(F.data == "adm:channel")
async def adm_channel(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    ch = await get_setting(session, "required_channel")
    link = await get_setting(session, "channel_link")
    await callback.message.answer("📢 Канал", reply_markup=channel_kb(ch, link))
    await callback.answer()


@router.callback_query(F.data == "adm:set_channel")
async def set_ch(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_channel)
    await callback.message.answer("Username (@channel) или ID (-100…), пусто = выкл:")
    await callback.answer()


@router.callback_query(F.data == "adm:set_channel_link")
async def set_ch_link(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_channel_link)
    await callback.message.answer("Ссылка https://t.me/…")
    await callback.answer()


@router.message(AdminStates.waiting_channel)
async def save_ch(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    await set_setting(session, "required_channel", (message.text or "").strip())
    await message.answer("✅ Сохранено", reply_markup=admin_menu_kb())
    await state.clear()


@router.message(AdminStates.waiting_channel_link)
async def save_ch_link(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    await set_setting(session, "channel_link", (message.text or "").strip())
    await message.answer("✅ Сохранено", reply_markup=admin_menu_kb())
    await state.clear()


@router.callback_query(F.data == "adm:stars_rate")
async def stars_rate(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    r = await get_setting(session, "stars_to_coins")
    await state.set_state(AdminStates.waiting_stars_rate)
    await callback.message.answer(f"Курс сейчас: 1 Star = {r} монет\nНовое число:")
    await callback.answer()


@router.message(AdminStates.waiting_stars_rate)
async def save_rate(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    try:
        val = int(message.text.strip())
        if val < 1:
            raise ValueError
        await set_setting(session, "stars_to_coins", str(val))
        await message.answer(f"✅ 1 Star = {val}", reply_markup=admin_menu_kb())
    except ValueError:
        await message.answer("Целое ≥ 1")
    await state.clear()


@router.callback_query(F.data == "adm:user")
async def adm_user(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_user_id)
    await callback.message.answer("Telegram ID юзера:")
    await callback.answer()


@router.message(AdminStates.waiting_user_id)
async def show_user(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    try:
        tid = int(message.text.strip())
    except ValueError:
        await message.answer("Нужен ID")
        return
    user = await get_user_by_tg(session, tid)
    if not user:
        await message.answer("Не найден")
        await state.clear()
        return
    gens = await session.scalar(
        select(func.count(Generation.id)).where(Generation.user_id == user.id)
    ) or 0
    await message.answer(
        f"TG: <code>{user.telegram_id}</code>\n@{user.username or '—'}\n"
        f"Баланс: {user.balance:.0f}\nФильмов: {gens}\nБлок: {user.is_blocked}",
        parse_mode="HTML",
        reply_markup=user_actions_kb(tid),
    )
    await state.clear()


@router.callback_query(F.data.startswith("adm:bal_add:"))
@router.callback_query(F.data.startswith("adm:bal_sub:"))
async def bal_op(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    parts = callback.data.split(":")
    op, tid = parts[1], int(parts[2])
    await state.set_state(AdminStates.waiting_balance_change)
    await state.update_data(target_tid=tid, bal_op="add" if op == "bal_add" else "sub")
    await callback.message.answer("Сколько монет?")
    await callback.answer()


@router.message(AdminStates.waiting_balance_change)
async def do_bal(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    try:
        amount = float(message.text.strip())
    except ValueError:
        await message.answer("Число")
        return
    amount = abs(amount) if data.get("bal_op") == "add" else -abs(amount)
    user = await get_user_by_tg(session, data["target_tid"])
    if not user:
        await message.answer("Не найден")
        await state.clear()
        return
    await change_balance(session, user, amount, "admin", f"admin {message.from_user.id}")
    await message.answer(f"✅ Баланс {user.telegram_id}: {user.balance:.0f}", reply_markup=admin_menu_kb())
    await state.clear()


@router.callback_query(F.data.startswith("adm:block:"))
async def block_u(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    tid = int(callback.data.split(":")[2])
    user = await get_user_by_tg(session, tid)
    if user:
        user.is_blocked = True
        await session.commit()
        await callback.answer("Заблокирован", show_alert=True)
    else:
        await callback.answer("Нет", show_alert=True)


@router.callback_query(F.data.startswith("adm:unblock:"))
async def unblock_u(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    tid = int(callback.data.split(":")[2])
    user = await get_user_by_tg(session, tid)
    if user:
        user.is_blocked = False
        await session.commit()
        await callback.answer("Разблокирован", show_alert=True)
    else:
        await callback.answer("Нет", show_alert=True)


@router.callback_query(F.data == "adm:broadcast")
async def bc_start(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_broadcast)
    await callback.message.answer("Текст или фото с подписью:")
    await callback.answer()


@router.message(AdminStates.waiting_broadcast)
async def bc_prep(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.update_data(
        bc_text=message.text or message.caption,
        bc_photo=message.photo[-1].file_id if message.photo else None,
    )
    await message.answer("Отправить?", reply_markup=confirm_broadcast_kb())


@router.callback_query(F.data == "adm:broadcast_yes")
async def bc_go(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    data = await state.get_data()
    result = await session.execute(select(User.telegram_id).where(User.is_blocked == False))
    ids = [r[0] for r in result.all()]
    ok = fail = 0
    for tid in ids:
        try:
            if data.get("bc_photo"):
                await callback.bot.send_photo(tid, data["bc_photo"], caption=data.get("bc_text"))
            else:
                await callback.bot.send_message(tid, data.get("bc_text") or "")
            ok += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    await callback.message.answer(f"Готово: ok={ok} fail={fail}", reply_markup=admin_menu_kb())
    await state.clear()
    await callback.answer()


@router.callback_query(F.data == "adm:promo")
async def promo_m(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    await callback.message.answer("Промокоды", reply_markup=promo_menu_kb())
    await callback.answer()


@router.callback_query(F.data == "adm:promo_create")
async def promo_c(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_promo_code)
    await callback.message.answer("Код промокода:")
    await callback.answer()


@router.message(AdminStates.waiting_promo_code)
async def promo_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.update_data(promo_code=message.text.strip().upper())
    await state.set_state(AdminStates.waiting_promo_amount)
    await message.answer("Сколько монет?")


@router.message(AdminStates.waiting_promo_amount)
async def promo_amt(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        await state.update_data(promo_amount=float(message.text.strip()))
    except ValueError:
        await message.answer("Число")
        return
    await state.set_state(AdminStates.waiting_promo_uses)
    await message.answer("Макс. использований (0 = ∞):")


@router.message(AdminStates.waiting_promo_uses)
async def promo_uses(message: Message, state: FSMContext, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    try:
        uses = int(message.text.strip())
    except ValueError:
        await message.answer("Целое")
        return
    data = await state.get_data()
    session.add(
        PromoCode(
            code=data["promo_code"],
            amount=data["promo_amount"],
            max_uses=uses,
            created_by=message.from_user.id,
        )
    )
    try:
        await session.commit()
        await message.answer(f"✅ {data['promo_code']}", reply_markup=admin_menu_kb())
    except Exception as e:
        await session.rollback()
        await message.answer(f"Ошибка: {e}")
    await state.clear()


@router.callback_query(F.data == "adm:promo_list")
async def promo_list(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        return
    result = await session.execute(select(PromoCode).order_by(PromoCode.id.desc()).limit(20))
    promos = result.scalars().all()
    if not promos:
        await callback.message.answer("Пусто")
    else:
        lines = [
            f"{'✅' if p.is_active else '❌'} <code>{p.code}</code> {p.amount:.0f} ({p.used_count}/{p.max_uses or '∞'})"
            for p in promos
        ]
        await callback.message.answer("\n".join(lines), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "adm:api_balance")
async def api_bal(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        return
    try:
        bal = await api_client.get_balance()
        await callback.message.answer(f"API: <code>{bal}</code>", parse_mode="HTML")
    except Exception as e:
        await callback.message.answer(f"Ошибка: {e}")
    await callback.answer()
