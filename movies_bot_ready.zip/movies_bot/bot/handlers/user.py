from __future__ import annotations

import json

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, LabeledPrice, Message, PreCheckoutQuery
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession

from bot.config import settings
from bot.database import Generation, get_setting
from bot.keyboards.user_kb import (
    cancel_kb,
    confirm_kb,
    main_menu_kb,
    movies_kb,
    profile_kb,
    subscribe_kb,
    topup_kb,
)
from bot.services.grtkniv_api import api_client
from bot.services.user_service import apply_promo, change_balance, get_or_create_user
from bot.states.user_states import MovieStates, PromoStates

router = Router(name="user")

_movies_cache: list[dict] = []


async def _get_movies() -> list[dict]:
    global _movies_cache
    if not _movies_cache:
        _movies_cache = await api_client.get_movies() or []
    return _movies_cache


async def check_subscription(bot, user_id: int, session: AsyncSession) -> bool:
    channel = await get_setting(session, "required_channel")
    if not channel:
        return True
    try:
        member = await bot.get_chat_member(channel, user_id)
        return member.status in ("member", "administrator", "creator")
    except Exception as e:
        logger.warning(f"check_sub: {e}")
        return False


async def require_sub(message_or_cb, session: AsyncSession) -> bool:
    bot = message_or_cb.bot
    user_id = message_or_cb.from_user.id
    if user_id in settings.ADMIN_IDS:
        return True
    ok = await check_subscription(bot, user_id, session)
    if not ok:
        link = await get_setting(session, "channel_link")
        text = "⚠️ Подпишись на канал и нажми «Я подписался»."
        if isinstance(message_or_cb, Message):
            await message_or_cb.answer(text, reply_markup=subscribe_kb(link))
        else:
            await message_or_cb.message.answer(text, reply_markup=subscribe_kb(link))
            await message_or_cb.answer()
    return ok


@router.message(CommandStart())
async def cmd_start(message: Message, session: AsyncSession, state: FSMContext):
    await state.clear()
    user = await get_or_create_user(
        session, message.from_user.id, message.from_user.username, message.from_user.full_name
    )
    if user.is_blocked:
        await message.answer("🚫 Вы заблокированы.")
        return
    if not await require_sub(message, session):
        return
    welcome = await get_setting(session, "welcome_text")
    await message.answer(welcome or "🎬 Movies Bot", reply_markup=main_menu_kb())


@router.callback_query(F.data == "check_sub")
async def cb_check_sub(callback: CallbackQuery, session: AsyncSession):
    if await check_subscription(callback.bot, callback.from_user.id, session):
        await callback.message.answer("✅ Подписка подтверждена!", reply_markup=main_menu_kb())
    else:
        await callback.answer("Подписка не найдена.", show_alert=True)
    await callback.answer()


@router.message(F.text == "❌ Отмена")
@router.callback_query(F.data == "cancel")
async def cancel_handler(event: Message | CallbackQuery, state: FSMContext):
    await state.clear()
    if isinstance(event, CallbackQuery):
        try:
            await event.message.answer("Отменено.", reply_markup=main_menu_kb())
        except Exception:
            pass
        try:
            await event.answer()
        except Exception:
            pass
    else:
        await event.answer("Отменено.", reply_markup=main_menu_kb())


@router.message(F.text == "👤 Профиль")
async def profile(message: Message, session: AsyncSession):
    if not await require_sub(message, session):
        return
    user = await get_or_create_user(
        session, message.from_user.id, message.from_user.username, message.from_user.full_name
    )
    await message.answer(
        f"👤 <b>Профиль</b>\n\nID: <code>{user.telegram_id}</code>\n"
        f"Баланс: <b>{user.balance:.0f}</b> монет",
        parse_mode="HTML",
        reply_markup=profile_kb(),
    )


@router.callback_query(F.data == "open_topup")
@router.message(F.text == "💰 Пополнить")
async def topup(event: Message | CallbackQuery, session: AsyncSession):
    if isinstance(event, CallbackQuery):
        message = event.message
        await event.answer()
        if not await require_sub(event, session):
            return
    else:
        message = event
        if not await require_sub(message, session):
            return
    rate = int(await get_setting(session, "stars_to_coins") or "10")
    await message.answer(
        f"💰 Stars → монеты\nКурс: 1 Star = {rate} монет",
        reply_markup=topup_kb(rate),
    )


@router.callback_query(F.data.startswith("stars:"))
async def stars_invoice(callback: CallbackQuery):
    _, stars_s, coins_s = callback.data.split(":")
    stars, coins = int(stars_s), int(coins_s)
    await callback.bot.send_invoice(
        chat_id=callback.from_user.id,
        title=f"Пополнение {coins} монет",
        description=f"{coins} монет за {stars} Stars",
        payload=f"topup:{coins}",
        currency="XTR",
        prices=[LabeledPrice(label=f"{coins} монет", amount=stars)],
        provider_token="",
    )
    await callback.answer()


@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message, session: AsyncSession):
    payment = message.successful_payment
    if payment.invoice_payload.startswith("topup:"):
        coins = float(payment.invoice_payload.split(":")[1])
        user = await get_or_create_user(
            session, message.from_user.id, message.from_user.username, message.from_user.full_name
        )
        await change_balance(
            session, user, coins, "deposit", f"Stars {payment.total_amount}",
            payment_id=payment.telegram_payment_charge_id,
        )
        await message.answer(
            f"✅ +{coins:.0f} монет. Баланс: {user.balance:.0f}",
            reply_markup=main_menu_kb(),
        )


@router.callback_query(F.data == "open_promo")
@router.message(F.text == "🎟 Промокод")
async def promo_start(event: Message | CallbackQuery, state: FSMContext, session: AsyncSession):
    if isinstance(event, CallbackQuery):
        await event.answer()
        msg = event.message
        if not await require_sub(event, session):
            return
    else:
        msg = event
        if not await require_sub(msg, session):
            return
    await state.set_state(PromoStates.waiting_code)
    await msg.answer("Введи промокод:", reply_markup=cancel_kb())


@router.message(PromoStates.waiting_code)
async def promo_apply(message: Message, state: FSMContext, session: AsyncSession):
    if message.text == "❌ Отмена":
        await state.clear()
        await message.answer("Отменено.", reply_markup=main_menu_kb())
        return
    user = await get_or_create_user(
        session, message.from_user.id, message.from_user.username, message.from_user.full_name
    )
    ok, text = await apply_promo(session, user, message.text.strip())
    await state.clear()
    await message.answer(text, reply_markup=main_menu_kb())


@router.message(F.text == "ℹ️ Помощь")
async def help_msg(message: Message):
    await message.answer(
        "🎬 <b>Movies Bot</b>\n\n"
        "1. Пополни баланс\n"
        "2. Нажми «🎬 Фильм»\n"
        "3. Отправь фото\n"
        "4. Выбери шаблон фильма\n"
        "5. Подтверди — результат придёт в чат\n\n"
        "API: GET /api/movies + POST /api/movies/generate",
        parse_mode="HTML",
        reply_markup=main_menu_kb(),
    )


# ─── Movies flow ──────────────────────────────────────────────────────

@router.message(F.text == "🎬 Фильм")
async def start_movie(message: Message, state: FSMContext, session: AsyncSession):
    if not await require_sub(message, session):
        return
    user = await get_or_create_user(
        session, message.from_user.id, message.from_user.username, message.from_user.full_name
    )
    price = float(await get_setting(session, "price_movie") or "150")
    if user.balance < price:
        await message.answer(
            f"Недостаточно монет. Нужно {price:.0f}, у тебя {user.balance:.0f}.",
            reply_markup=main_menu_kb(),
        )
        return
    await state.set_state(MovieStates.waiting_photo)
    await state.update_data(price=price)
    await message.answer(
        f"Отправь фото для фильма.\nСтоимость: <b>{price:.0f}</b> монет.",
        parse_mode="HTML",
        reply_markup=cancel_kb(),
    )


@router.message(MovieStates.waiting_photo, F.photo)
async def got_photo(message: Message, state: FSMContext):
    try:
        photo = message.photo[-1]
        await state.update_data(file_id=photo.file_id)
        await message.answer("Загружаю шаблоны фильмов…")
        movies = await _get_movies()
        if not movies:
            await message.answer(
                "Не удалось загрузить список фильмов. Проверь API-ключ.",
                reply_markup=main_menu_kb(),
            )
            await state.clear()
            return
        await state.set_state(MovieStates.choosing_movie)
        await message.answer(
            f"Выбери шаблон ({len(movies)} шт.):",
            reply_markup=movies_kb(movies, page=0),
        )
    except Exception as e:
        logger.exception("got_photo")
        await state.clear()
        await message.answer(f"❌ Ошибка: {e}", reply_markup=main_menu_kb())


@router.message(MovieStates.waiting_photo)
async def need_photo(message: Message):
    if message.text == "❌ Отмена":
        return
    await message.answer("Нужно отправить фото.")


@router.callback_query(F.data.startswith("movies_page:"))
async def movies_page(callback: CallbackQuery, state: FSMContext):
    try:
        page = int(callback.data.split(":")[1])
        movies = await _get_movies()
        await callback.message.edit_reply_markup(reply_markup=movies_kb(movies, page=page))
    except Exception as e:
        logger.exception("movies_page")
        try:
            await callback.message.answer(f"Ошибка: {e}")
        except Exception:
            pass
    try:
        await callback.answer()
    except Exception:
        pass


@router.callback_query(F.data.startswith("movie:"))
async def choose_movie(callback: CallbackQuery, state: FSMContext):
    try:
        movie_id = callback.data.split(":", 1)[1]
        movies = await _get_movies()
        name = next((m.get("name") for m in movies if m.get("id") == movie_id), movie_id)
        data = await state.get_data()
        price = float(data.get("price") or 150)
        await state.update_data(movie_id=movie_id, movie_name=name)
        await state.set_state(MovieStates.confirming)
        await callback.message.answer(
            f"Подтверди генерацию фильма:\n\n"
            f"Шаблон: <b>{name}</b>\n"
            f"ID: <code>{movie_id}</code>\n"
            f"Цена: {price:.0f} монет",
            parse_mode="HTML",
            reply_markup=confirm_kb(),
        )
    except Exception as e:
        logger.exception("choose_movie")
        try:
            await callback.message.answer(f"Ошибка: {e}")
        except Exception:
            pass
    try:
        await callback.answer()
    except Exception:
        pass


@router.callback_query(F.data == "confirm_movie")
async def confirm_movie(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    try:
        await callback.answer("Запускаю…")
    except Exception:
        pass

    data = await state.get_data()
    file_id = data.get("file_id")
    movie_id = data.get("movie_id")
    movie_name = data.get("movie_name") or movie_id
    try:
        price = float(data.get("price") or 150)
    except (TypeError, ValueError):
        price = 150.0

    chat_id = callback.message.chat.id if callback.message else callback.from_user.id

    async def say(text: str, **kwargs):
        try:
            await callback.bot.send_message(chat_id, text, **kwargs)
        except Exception as e:
            logger.error(f"say: {e}")

    if not file_id or not movie_id:
        await say("Данные потеряны. Начни заново: /start")
        await state.clear()
        return

    user = await get_or_create_user(
        session, callback.from_user.id, callback.from_user.username, callback.from_user.full_name
    )
    if user.balance < price:
        await say(f"Недостаточно монет ({user.balance:.0f} / {price:.0f}).")
        await state.clear()
        return

    await say("⏳ Скачиваю фото…")
    try:
        file = await callback.bot.get_file(file_id)
        bio = await callback.bot.download_file(file.file_path)
        image_bytes = bio.read()
    except Exception as e:
        logger.exception("download")
        await say(f"❌ Не удалось скачать фото: {e}")
        await state.clear()
        return

    await change_balance(session, user, -price, "spend", f"Movie {movie_name}")
    webhook = f"{settings.WEBHOOK_BASE_URL.rstrip('/')}/webhook/generation"
    await say(f"⏳ Отправляю в API (фильм: {movie_name})…")

    try:
        result = await api_client.generate_movie(
            image_bytes=image_bytes,
            movie_id=movie_id,
            webhook=webhook,
        )
    except Exception as e:
        logger.exception("api movie")
        await change_balance(session, user, price, "refund", "Ошибка API")
        await say(f"❌ Ошибка API: {e}\nМонеты возвращены.")
        await state.clear()
        return
    finally:
        image_bytes = None

    if result.get("error"):
        await change_balance(session, user, price, "refund", "Ошибка API")
        await say(f"❌ {result.get('error')}\nМонеты возвращены.")
        await state.clear()
        return

    id_gen = result.get("id_gen") or "?"
    queue_time = result.get("queueTime", "?")
    try:
        session.add(
            Generation(
                user_id=user.id,
                gen_type="movie",
                model_name=str(movie_name)[:200],
                id_gen=str(id_gen),
                status="pending",
                price=price,
                params_json=json.dumps({"movieId": movie_id, "name": movie_name}),
            )
        )
        await session.commit()
    except Exception:
        logger.exception("save gen")

    await say(
        f"✅ Фильм в очереди!\n"
        f"ID: <code>{id_gen}</code>\n"
        f"Шаблон: {movie_name}\n"
        f"Ожидание ~{queue_time} сек.\n\n"
        f"Результат придёт сюда автоматически.",
        parse_mode="HTML",
    )
    await say("Главное меню:", reply_markup=main_menu_kb())
    await state.clear()
