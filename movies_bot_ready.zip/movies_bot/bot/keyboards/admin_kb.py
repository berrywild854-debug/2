from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📊 Статистика", callback_data="adm:stats"),
        InlineKeyboardButton(text="👤 Юзер", callback_data="adm:user"),
    )
    builder.row(
        InlineKeyboardButton(text="📢 Рассылка", callback_data="adm:broadcast"),
        InlineKeyboardButton(text="🎟 Промокоды", callback_data="adm:promo"),
    )
    builder.row(
        InlineKeyboardButton(text="💵 Цена фильма", callback_data="adm:price"),
        InlineKeyboardButton(text="📢 Канал", callback_data="adm:channel"),
    )
    builder.row(
        InlineKeyboardButton(text="⭐ Курс Stars", callback_data="adm:stars_rate"),
        InlineKeyboardButton(text="🔑 API баланс", callback_data="adm:api_balance"),
    )
    builder.row(InlineKeyboardButton(text="❌ Закрыть", callback_data="cancel"))
    return builder.as_markup()


def user_actions_kb(telegram_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="➕ Баланс", callback_data=f"adm:bal_add:{telegram_id}"),
        InlineKeyboardButton(text="➖ Баланс", callback_data=f"adm:bal_sub:{telegram_id}"),
    )
    builder.row(
        InlineKeyboardButton(text="🚫 Блок", callback_data=f"adm:block:{telegram_id}"),
        InlineKeyboardButton(text="✅ Разблок", callback_data=f"adm:unblock:{telegram_id}"),
    )
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="adm:menu"))
    return builder.as_markup()


def promo_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="➕ Создать", callback_data="adm:promo_create"))
    builder.row(InlineKeyboardButton(text="📋 Список", callback_data="adm:promo_list"))
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="adm:menu"))
    return builder.as_markup()


def confirm_broadcast_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Отправить", callback_data="adm:broadcast_yes"),
        InlineKeyboardButton(text="❌ Отмена", callback_data="adm:menu"),
    )
    return builder.as_markup()


def channel_kb(channel: str, link: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text=f"Канал: {channel or 'не задан'}", callback_data="adm:set_channel")
    )
    builder.row(
        InlineKeyboardButton(text=f"Ссылка: {link or 'не задана'}", callback_data="adm:set_channel_link")
    )
    builder.row(InlineKeyboardButton(text="◀️ Назад", callback_data="adm:menu"))
    return builder.as_markup()
