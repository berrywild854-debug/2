from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder


def main_menu_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="🎬 Фильм"))
    builder.row(
        KeyboardButton(text="👤 Профиль"),
        KeyboardButton(text="💰 Пополнить"),
    )
    builder.row(
        KeyboardButton(text="🎟 Промокод"),
        KeyboardButton(text="ℹ️ Помощь"),
    )
    return builder.as_markup(resize_keyboard=True)


def cancel_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="❌ Отмена"))
    return builder.as_markup(resize_keyboard=True)


def subscribe_kb(channel_link: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if channel_link:
        builder.row(InlineKeyboardButton(text="📢 Подписаться", url=channel_link))
    builder.row(InlineKeyboardButton(text="✅ Я подписался", callback_data="check_sub"))
    return builder.as_markup()


def movies_kb(movies: list[dict], page: int = 0, per_page: int = 8) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    start = page * per_page
    chunk = movies[start : start + per_page]
    for m in chunk:
        name = m.get("name") or m.get("id") or "?"
        dur = m.get("duration")
        label = f"{name}"
        if dur:
            label += f" ({int(dur)}с)"
        mid = m["id"]
        builder.row(
            InlineKeyboardButton(text=label[:40], callback_data=f"movie:{mid}")
        )
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"movies_page:{page-1}"))
    if start + per_page < len(movies):
        nav.append(InlineKeyboardButton(text="➡️", callback_data=f"movies_page:{page+1}"))
    if nav:
        builder.row(*nav)
    builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"))
    return builder.as_markup()


def confirm_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="✅ Запустить", callback_data="confirm_movie"),
        InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"),
    )
    return builder.as_markup()


def topup_kb(stars_to_coins: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    packages = [50, 100, 300, 500, 1000]
    for coins in packages:
        stars = max(1, coins // max(stars_to_coins, 1))
        builder.row(
            InlineKeyboardButton(
                text=f"⭐ {stars} Stars → {coins} монет",
                callback_data=f"stars:{stars}:{coins}",
            )
        )
    builder.row(InlineKeyboardButton(text="❌ Закрыть", callback_data="cancel"))
    return builder.as_markup()


def profile_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="💰 Пополнить", callback_data="open_topup"),
        InlineKeyboardButton(text="🎟 Промокод", callback_data="open_promo"),
    )
    return builder.as_markup()
