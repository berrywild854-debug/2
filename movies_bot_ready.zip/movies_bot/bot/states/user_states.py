from aiogram.fsm.state import State, StatesGroup


class MovieStates(StatesGroup):
    waiting_photo = State()
    choosing_movie = State()
    confirming = State()


class PromoStates(StatesGroup):
    waiting_code = State()


class AdminStates(StatesGroup):
    waiting_channel = State()
    waiting_channel_link = State()
    waiting_price = State()
    waiting_user_id = State()
    waiting_balance_change = State()
    waiting_broadcast = State()
    waiting_promo_code = State()
    waiting_promo_amount = State()
    waiting_promo_uses = State()
    waiting_stars_rate = State()
