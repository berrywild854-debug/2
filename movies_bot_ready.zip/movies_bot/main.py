"""Movies-only bot. python main.py"""
from __future__ import annotations

import asyncio
import sys
import threading

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from loguru import logger
import uvicorn

from bot.config import settings
from bot.database import init_db
from bot.handlers import setup_routers
from bot.middlewares.db import DbSessionMiddleware
from bot.services.grtkniv_api import api_client
from bot.webhook_server import app as webhook_app, set_bot


def run_webhook_in_thread():
    config = uvicorn.Config(webhook_app, host="0.0.0.0", port=8081, log_level="warning")
    uvicorn.Server(config).run()


async def main():
    logger.remove()
    logger.add(sys.stderr, level="INFO")
    logger.add("/tmp/movies_bot.log", level="DEBUG", rotation="20 MB", enqueue=True)

    await init_db()
    logger.info("DB ready")

    threading.Thread(target=run_webhook_in_thread, daemon=True).start()
    logger.info("Webhook on :8081")

    bot = Bot(token=settings.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    set_bot(bot)

    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware())

    @dp.errors()
    async def on_err(event, exception):
        logger.exception(f"Unhandled: {exception}")
        return True

    dp.include_router(setup_routers())
    logger.info("Polling…")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Stop")
